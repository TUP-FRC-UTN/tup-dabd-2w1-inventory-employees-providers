export interface EmpModificarAsistencia {
    id: number,
    state: string
}
