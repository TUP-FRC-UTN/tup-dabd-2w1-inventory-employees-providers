export interface DtoProducto {
    id: number;
    name: string;
    reusable: boolean;
    category: string;
    amountDetails: number;
}
