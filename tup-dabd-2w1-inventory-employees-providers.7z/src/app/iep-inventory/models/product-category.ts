export interface ProductCategory {
    id: number;
    category: string;
    discontinued: boolean;
}
