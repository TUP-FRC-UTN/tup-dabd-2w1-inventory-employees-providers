export interface GetWarehouseMovementRequest {
    createdDate?: string,
    applicantOrResponsible?: string,
    productId?: number,
    movementType?: string,
    detailCount?: number
}
