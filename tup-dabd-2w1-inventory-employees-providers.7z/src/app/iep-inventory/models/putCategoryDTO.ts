export interface PutCategoryDTO {
}
