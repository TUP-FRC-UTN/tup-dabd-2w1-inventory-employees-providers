import { CreateProductDtoClass } from "./create-product-dto-class";

describe('CreateProductDtoClass', () => {
  it('should create an instance', () => {
    expect(new CreateProductDtoClass()).toBeTruthy();
  });
});
