export interface CreateSupplierRequest {
    name: string,
    healthInsurance: number,
    address: string,
    supplierType: string,
    description: string,
    phoneNumber: string,
    createdUser: number

}
