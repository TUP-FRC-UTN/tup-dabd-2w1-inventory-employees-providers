export class CreateProductDtoClass {
    name: string|undefined;
    reusable: boolean|undefined;
    minAmountWarning: number|undefined;
    amount: number|undefined;
    description: string|undefined;
    unitPrice: number|undefined;
    state_id:number|undefined;
    supplier_id: number|undefined;
    category_id: number|undefined;

   constructor(){}
   
}
