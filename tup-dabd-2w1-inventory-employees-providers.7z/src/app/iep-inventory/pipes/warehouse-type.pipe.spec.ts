import { WarehouseTypePipe } from './warehouse-type.pipe';

describe('WarehouseTypePipe', () => {
  it('create an instance', () => {
    const pipe = new WarehouseTypePipe();
    expect(pipe).toBeTruthy();
  });
});
