import { SupplierTypePipe } from './supplier-type.pipe';

describe('SupplierTypePipe', () => {
  it('create an instance', () => {
    const pipe = new SupplierTypePipe();
    expect(pipe).toBeTruthy();
  });
});
