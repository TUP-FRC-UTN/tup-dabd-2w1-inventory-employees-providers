import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IepInventoryRoutingModule } from './iep-inventory-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    IepInventoryRoutingModule
  ]
})
export class IepInventoryModule { }
