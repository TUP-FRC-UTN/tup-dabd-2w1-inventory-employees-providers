import { Component } from '@angular/core';

@Component({
  selector: 'app-iep-back-button',
  standalone: true,
  templateUrl: './iep-back-button.component.html'
})
export class iepBackButtonComponent {
  volver() {
    // Implementar lógica para volver
  }
}