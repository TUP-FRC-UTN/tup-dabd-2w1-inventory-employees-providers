export interface EmpListadoAsistencias {
    id: number,
    employeeId: number,
    employeeName: string,
    date: string
    arrivalTime: string
    departureTime: string
    state: string
    justification: string
}
