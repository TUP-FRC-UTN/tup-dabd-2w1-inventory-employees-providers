export interface ChargeRequest {
    charge: string;
    description: string;
}
