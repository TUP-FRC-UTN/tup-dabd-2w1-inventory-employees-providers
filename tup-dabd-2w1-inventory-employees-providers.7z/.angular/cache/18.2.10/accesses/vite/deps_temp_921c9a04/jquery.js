import {
  require_jquery
} from "./chunk-ZA2ML5SA.js";
import "./chunk-S35DAJRX.js";
export default require_jquery();
//# sourceMappingURL=jquery.js.map
