import {
  dataTables_default
} from "./chunk-DL4CI3ZO.js";
import {
  require_jquery
} from "./chunk-ZA2ML5SA.js";
import {
  __toESM
} from "./chunk-S35DAJRX.js";

// node_modules/datatables.net-bs5/js/dataTables.bootstrap5.mjs
var import_jquery = __toESM(require_jquery(), 1);
var $ = import_jquery.default;
$.extend(true, dataTables_default.defaults, {
  renderer: "bootstrap"
});
$.extend(true, dataTables_default.ext.classes, {
  container: "dt-container dt-bootstrap5",
  search: {
    input: "form-control form-control-sm"
  },
  length: {
    select: "form-select form-select-sm"
  },
  processing: {
    container: "dt-processing card"
  },
  layout: {
    row: "row mt-2 justify-content-between",
    cell: "d-md-flex justify-content-between align-items-center",
    tableCell: "col-12",
    start: "dt-layout-start col-md-auto me-auto",
    end: "dt-layout-end col-md-auto ms-auto",
    full: "dt-layout-full col-md"
  }
});
dataTables_default.ext.renderer.pagingButton.bootstrap = function(settings, buttonType, content, active, disabled) {
  var btnClasses = ["dt-paging-button", "page-item"];
  if (active) {
    btnClasses.push("active");
  }
  if (disabled) {
    btnClasses.push("disabled");
  }
  var li = $("<li>").addClass(btnClasses.join(" "));
  var a = $("<button>", {
    "class": "page-link",
    role: "link",
    type: "button"
  }).html(content).appendTo(li);
  return {
    display: li,
    clicker: a
  };
};
dataTables_default.ext.renderer.pagingContainer.bootstrap = function(settings, buttonEls) {
  return $("<ul/>").addClass("pagination").append(buttonEls);
};
var dataTables_bootstrap5_default = dataTables_default;
export {
  dataTables_bootstrap5_default as default
};
/*! Bundled license information:

datatables.net-bs5/js/dataTables.bootstrap5.mjs:
  (*! DataTables Bootstrap 5 integration
   * © SpryMedia Ltd - datatables.net/license
   *)
*/
//# sourceMappingURL=datatables__net-bs5.js.map
