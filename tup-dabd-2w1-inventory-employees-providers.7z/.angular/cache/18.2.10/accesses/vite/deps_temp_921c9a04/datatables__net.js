import {
  dataTables_default
} from "./chunk-DL4CI3ZO.js";
import "./chunk-ZA2ML5SA.js";
import "./chunk-S35DAJRX.js";
export {
  dataTables_default as default
};
//# sourceMappingURL=datatables__net.js.map
