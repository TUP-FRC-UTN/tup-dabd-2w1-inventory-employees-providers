import {
  dataTables_default
} from "./chunk-DL4CI3ZO.js";
import {
  require_jquery
} from "./chunk-ZA2ML5SA.js";
import {
  __toESM
} from "./chunk-S35DAJRX.js";

// node_modules/datatables.net-dt/js/dataTables.dataTables.mjs
var import_jquery = __toESM(require_jquery(), 1);
var dataTables_dataTables_default = dataTables_default;
export {
  dataTables_dataTables_default as default
};
/*! Bundled license information:

datatables.net-dt/js/dataTables.dataTables.mjs:
  (*! DataTables styling integration
   * © SpryMedia Ltd - datatables.net/license
   *)
*/
//# sourceMappingURL=datatables__net-dt.js.map
