import {
  require_jquery
} from "./chunk-D65DSPJZ.js";
import "./chunk-TXDUYLVM.js";
export default require_jquery();
//# sourceMappingURL=jquery.js.map
