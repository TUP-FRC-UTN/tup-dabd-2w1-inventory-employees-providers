import {
  dataTables_default
} from "./chunk-CMEOO7BQ.js";
import "./chunk-D65DSPJZ.js";
import "./chunk-TXDUYLVM.js";
export {
  dataTables_default as default
};
//# sourceMappingURL=datatables__net.js.map
