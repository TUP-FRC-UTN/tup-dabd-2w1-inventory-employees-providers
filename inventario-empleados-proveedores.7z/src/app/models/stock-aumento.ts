export interface StockAumento {
    productId: number;
  supplierId: number;
  quantity: number;
  description: string;
  unit_price: number;
}
