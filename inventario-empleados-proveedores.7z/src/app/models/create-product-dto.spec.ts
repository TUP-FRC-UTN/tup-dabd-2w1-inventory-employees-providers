import { CreateProductDTO } from './create-product-dto';

describe('CreateProductDTO', () => {
  it('should create an instance', () => {
    expect(new CreateProductDTO()).toBeTruthy();
  });
});
