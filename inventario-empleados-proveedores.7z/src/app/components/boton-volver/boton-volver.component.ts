import { Component } from '@angular/core';

@Component({
  selector: 'app-boton-volver',
  standalone: true,
  templateUrl: './boton-volver.component.html'
})
export class BotonVolverComponent {
  volver() {
    // Implementar lógica para volver
  }
}